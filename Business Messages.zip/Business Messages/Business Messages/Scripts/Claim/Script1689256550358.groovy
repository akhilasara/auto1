import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import org.testng.Assert as Assert
import org.testng.asserts.SoftAssert

WebUI.callTestCase(findTestCase('Login'),  [:], FailureHandling.STOP_ON_FAILURE)

WebUI.switchToWindowTitle('Longos Company of Canada')

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/span_Inbox'))

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/switch_dashboard'))

WebUI.verifyElementVisible(findTestObject('Object Repository/Page_Longos Company of Canada/title'))

WebUI.verifyElementVisible(findTestObject('Object Repository/Page_Longos Company of Canada/Google_logo'))

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/initial_click-unclaim'))

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/unclaim_conversation'))

String unclaim_count= WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/count_unclaimed'))

WebUI.takeFullPageScreenshot("D://BusinessMessagesScreenshots//ClaimPage_1.png")

String count_unclaim = unclaim_count.substring(unclaim_count.indexOf('(')+1 , unclaim_count.indexOf(')')).trim().toInteger()

println(count_unclaim)

int expectedUNclaimCount= count_unclaim.toInteger()-1
println(expectedUNclaimCount)

String claim_count= WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/claimed_count'))

String count_claim = claim_count.substring(claim_count.indexOf('(')+1 , claim_count.indexOf(')')).trim().toInteger()

println(count_claim)

int expected_count_claim=count_claim.toInteger()+1
println(expected_count_claim)

String conversation_count= WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/myconversation_count'))

String count_conversation = conversation_count.substring(conversation_count.indexOf('(')+1 , conversation_count.indexOf(')')).trim().toInteger()

println(count_conversation)

int expected_count_conversation=count_conversation.toInteger()+1

println(expected_count_conversation)

String displaynme_unclaimed= WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/displayname'))

println(displaynme_unclaimed)

String address_recipient= WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/recipient_Address'))

println(address_recipient)

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/btnclaim'))

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/claimed_click'))

String displaynme_claimed= WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/displayname'))

println(displaynme_claimed)

Assert.assertEquals(displaynme_unclaimed,displaynme_claimed)

String address_recipient_unclaimed= WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/recipient_Address'))

println(address_recipient_unclaimed)

Assert.assertEquals(address_recipient, address_recipient_unclaimed)

String unclaim_count_click= WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/count_unclaimed'))

int count_unclaim_click = unclaim_count_click.substring(unclaim_count_click.indexOf('(')+1 , unclaim_count_click.indexOf(')')).trim().toInteger()

println(count_unclaim_click)

Assert.assertEquals(expectedUNclaimCount,count_unclaim_click)

String claim_count_click= WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/claimed_count'))

int count_claim_click = claim_count_click.substring(claim_count_click.indexOf('(')+1 , claim_count_click.indexOf(')')).trim().toInteger()

println(count_claim_click)

Assert.assertEquals(count_claim_click,expected_count_claim)

String conversation_count_click= WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/myconversation_count'))

int count_conversation_click = conversation_count_click.substring(conversation_count_click.indexOf('(')+1 , conversation_count_click.indexOf(')')).trim().toInteger()

println(count_conversation_click)

Assert.assertEquals(count_conversation_click,expected_count_conversation)

WebUI.verifyElementPresent(findTestObject('Object Repository/Page_Longos Company of Canada/txt_inputmessage'), 0)

WebUI.takeFullPageScreenshot("D://BusinessMessagesScreenshots//ClaimPage_2.png")

WebUI.closeBrowser()

