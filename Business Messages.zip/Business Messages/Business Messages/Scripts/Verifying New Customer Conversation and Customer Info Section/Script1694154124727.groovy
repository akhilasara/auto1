import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import org.testng.Assert as Assert
import org.testng.asserts.SoftAssert
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.By as By
import org.openqa.selenium.WebElement as WebElement
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory

WebUI.callTestCase(findTestCase('Login'),  [:], FailureHandling.STOP_ON_FAILURE)

WebUI.switchToWindowTitle('Longos Company of Canada')

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/span_Inbox'))

WebUI.verifyElementVisible(findTestObject('Object Repository/Page_Longos Company of Canada/title'))

driver = DriverFactory.getWebDriver()

WebUI.setText(findTestObject('Object Repository/Page_Longos Company of Canada/input_Read Manual_unclaimed-search'), 'rah')
WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/i_Read Manual_unclaimed-search-btn'))

unclaim_count= WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/count_unclaimed'))

count_unclaim = unclaim_count.substring(unclaim_count.indexOf('(')+1 , unclaim_count.indexOf(')')).trim().toInteger()

println(count_unclaim)

List< WebElement> objunclaim= driver.findElements(By.xpath('(//*[@class="bm-card"])'))
int unclaimcount=	objunclaim.size()
println(unclaimcount)

for(int j=1; j<=count_unclaim;j++)
{
	println(j)
	//WebElement obj_conversation = driver.findElement(By.xpath('(//div[@class="small bm-card-date"])[' + unclaimcount_search + ']'))
	 WebElement obj_singleconversation= driver.findElement(By.xpath('(//div[@class="bm-card-details bold"]/div)[' + j + ']'))
	String conversation_text = obj_singleconversation.getText()
	println(conversation_text)
WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/initial_click-unclaim'))

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/unclaim_conversation'))

String displaynme_unclaimed= WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/displayname'))

println(displaynme_unclaimed)

String address_recipient= WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/recipient_Address'))

println(address_recipient)
}