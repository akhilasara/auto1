import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.webui.driver.DriverFactory
import org.openqa.selenium.By
import org.openqa.selenium.WebElement
import org.openqa.selenium.JavascriptExecutor
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import org.openqa.selenium.interactions.Actions
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension

WebUI.callTestCase(findTestCase('Login'),  [:], FailureHandling.STOP_ON_FAILURE)
Robot robot = new Robot();
WebElement hoveredElement
WebUI.switchToWindowTitle('Longos Company of Canada')
driver = DriverFactory.getWebDriver()

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/span_Inbox'))

WebUI.verifyElementVisible(findTestObject('Object Repository/Page_Longos Company of Canada/title'))

//WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/unclaimborder'))
//Actions act = new Actions(driver)
//act.sendKeys(Keys.ARROW_DOWN).perform()
//act.sendKeys(Keys.ARROW_DOWN).perform()
//act.keyDown(DOWN).build().perform()

//WebUI.delay(5000)
//act.keyUp(DOWN).build().perform()
//act.perform()
unclaim_count= WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/count_unclaimed'))

count_unclaim = unclaim_count.substring(unclaim_count.indexOf('(')+1 , unclaim_count.indexOf(')')).trim().toInteger()

println(count_unclaim)

// Get the WebDriver instance from DriverFactory
List< WebElement> objunclaim_search= driver.findElements(By.xpath('//*[@id="unclaimed-count"]'))
int unclaimcount_search=	objunclaim_search.size()
println(count_unclaim)
for(int j=1;j<=count_unclaim;j++)
	{
		println(j)
 hoveredElement = driver.findElement(By.xpath('(//div[@class="bm-card-details bold"]/div[1])[' + j + ']'))
hoveredElement.click()
robot.keyPress(KeyEvent.VK_DOWN);
//robot.delay(2000);
robot.keyRelease(KeyEvent.VK_DOWN);
robot.keyPress(KeyEvent.VK_DOWN);
robot.keyRelease(KeyEvent.VK_DOWN);
		 WebElement obj_singleconversation= driver.findElement(By.xpath('(//div[@class="bm-card-details bold"]/div[1])[' + j + ']'))
		String conversation_text = obj_singleconversation.getText()
		println(conversation_text)
	}
/*
WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/initial_click-unclaim'))

robot.keyPress(KeyEvent.VK_DOWN);
robot.delay(8000);
robot.keyRelease(KeyEvent.VK_DOWN);
WebElement hoveredElement1 = driver.findElement(By.xpath('(//div[@class="bm-card-details bold"]/div[1])[4]'))
hoveredElement1.click()
robot.keyPress(KeyEvent.VK_DOWN);
robot.delay(8000);
robot.keyRelease(KeyEvent.VK_DOWN);
WebElement hoveredElement2 = driver.findElement(By.xpath('(//div[@class="bm-card-details bold"]/div[1])[8]'))
hoveredElement2.click()
robot.keyPress(KeyEvent.VK_DOWN);
robot.delay(8000);
robot.keyRelease(KeyEvent.VK_DOWN);
WebElement hoveredElement3 = driver.findElement(By.xpath('(//div[@class="bm-card-details bold"]/div[1])[12]'))
hoveredElement3.click()
robot.keyPress(KeyEvent.VK_DOWN);
robot.delay(8000);
robot.keyRelease(KeyEvent.VK_DOWN);
WebElement hoveredElement4 = driver.findElement(By.xpath('(//div[@class="bm-card-details bold"]/div[1])[16]'))
hoveredElement4.click()
robot.keyPress(KeyEvent.VK_DOWN);
robot.delay(8000);
robot.keyRelease(KeyEvent.VK_DOWN);
WebElement hoveredElement5 = driver.findElement(By.xpath('(//div[@class="bm-card-details bold"]/div[1])[18]'))
hoveredElement5.click()
robot.keyPress(KeyEvent.VK_DOWN);
robot.delay(8000);
robot.keyRelease(KeyEvent.VK_DOWN);
WebElement hoveredElement6 = driver.findElement(By.xpath('(//div[@class="bm-card-details bold"]/div[1])[20]'))
hoveredElement6.click()
robot.keyPress(KeyEvent.VK_DOWN);
robot.delay(8000);
robot.keyRelease(KeyEvent.VK_DOWN);

// Scroll down by a specified number of pixels (e.g., 200 pixels)
WebElement hoveredElement = driver.findElement(By.xpath('(//div[@class="bm-card-details bold"]/div[1])[21]'))

Dimension dimen=hoveredElement.getSize()
//println(dimen.height+ "  "+ dimen.width)
println(dimen.height+ "  "+ dimen.width)

// Get the WebDriver instance from DriverFactory
def driver = DriverFactory.getWebDriver()

// Create an Actions object
Actions actions = new Actions(driver)
Point elementPosition = hoveredElement.getLocation();

		 int elementX = elementPosition.getX();

   int elementY = elementPosition.getY();

   System.out.println("Element X coordinate: " + elementX);

   System.out.println("Element Y coordinate: " + elementY);
   
   By elementLocator = By.xpath('(//div[@class="bm-card-details bold"]/div[1])[21]')
   
   
   WebElement element = driver.findElement(elementLocator)
   
	
   
   // Scroll down by performing a mouse scroll event
   actions.moveToElement(element).clickAndHold().moveByOffset(303, 588).release().perform()
// Find the element to hover over



*/









/*
//WebUI.setText(findTestObject('Object Repository/Page_Longos Company of Canada/input_Read Manual_unclaimed-search'), 'rah')
//WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/i_Read Manual_unclaimed-search-btn'))
// Specify your desired count of elements
int desiredElementCount = 22 // Change this to your desired count
int maxScrollAttempts = 22 // Maximum number of scroll attempts

// Loop to scroll down and check element count
for (int attempt = 0; attempt < maxScrollAttempts; attempt++) {
	// Scroll down by a specific amount (you can adjust the value)
	int scrollAmount = 200 // Change this value as needed
	scrollDown(scrollAmount)

	// Wait for a short time to allow the content to load (you can adjust the wait time)
	WebUI.delay(2)

	// Check the count of elements you are interested in using XPath
	
	List<WebElement> elements = DriverFactory.getWebDriver().findElements(By.xpath('//div[@class="bm-card-details bold"]/div'))
	int currentElementCount = elements.size()
	println(currentElementCount)

	// Check if the desired count is reached
	if (currentElementCount >= desiredElementCount) {
		break // Exit the loop if the desired count is reached
	}
}

// Function to scroll down using JavaScript
void scrollDown(int scrollAmount) {
	JavascriptExecutor js = ((JavascriptExecutor) DriverFactory.getWebDriver())
	String script = "window.scrollBy(0, " + scrollAmount + ");"
	js.executeScript(script)
}





 
 // Input date in MM/dd format
 String inputDateStr = date_unclaim // Change this to your desired input date
 
 // Define a SimpleDateFormat object for parsing and formatting the date
 SimpleDateFormat dateFormat1 = new SimpleDateFormat("MM-dd")
 
 try {
	 // Parse the input date string
	 Date inputDate = dateFormat1.parse(inputDateStr)
	 
	 // Create a Calendar instance and set it to the input date
	 Calendar calendar = Calendar.getInstance()
	 calendar.setTime(inputDate)
	 
	 // Decrement 30 days from the input date
	 calendar.add(Calendar.DAY_OF_MONTH, -30)
	 
	 // Get the new date after decrementing 30 days
	 Date newDate1 = calendar.getTime()
	 
	 // Format the new date to MM/dd format
	 String newDateStr = dateFormat1.format(newDate1)
	 
	 // Print the result
	 println("Original Date: " + inputDateStr)
	 println("Date after decrementing 30 days: " + newDateStr)
	 */
/*} catch (Exception e) {
 // Handle any exceptions that may occur
 println("Error: " + e.getMessage())
}*/
