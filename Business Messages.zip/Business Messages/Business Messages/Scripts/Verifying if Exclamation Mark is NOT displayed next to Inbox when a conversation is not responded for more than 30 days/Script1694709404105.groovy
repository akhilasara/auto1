import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import org.testng.Assert as Assert
import org.testng.asserts.SoftAssert
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.By as By
import org.openqa.selenium.WebElement as WebElement
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import java.sql.Timestamp as Timestamp
import java.time.Instant as Instant
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;


Robot robot = new Robot();
WebElement ElementClick
Date currentDate = new Date()

String dateFormat = 'MM-dd'

SimpleDateFormat sdf = new SimpleDateFormat(dateFormat)

// Format the current date using the SimpleDateFormat object
String formattedDate = sdf.format(currentDate)

// Print the formatted date
println('Current Date: ' + formattedDate)
Date inputDate1 = sdf.parse(formattedDate)
Calendar calendar1 = Calendar.getInstance()
calendar1.setTime(inputDate1)

// Decrement 30 days from the input date
calendar1.add(Calendar.DAY_OF_MONTH, -30)

Date newDate = calendar1.getTime()
// Format the new date to MM/dd format
String today_30dys = sdf.format(newDate)

println(today_30dys)

WebUI.callTestCase(findTestCase('Login'),  [:], FailureHandling.STOP_ON_FAILURE)

WebUI.switchToWindowTitle('Longos Company of Canada')
driver = DriverFactory.getWebDriver()

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/span_Inbox'))

WebUI.verifyElementVisible(findTestObject('Object Repository/Page_Longos Company of Canada/title'))

WebUI.takeFullPageScreenshot("D://BusinessMessagesScreenshots//verifying_exclamationmark_notPresentmorethan_30days1.png")
WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/myConversation'))
String my_conversation_click= WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/myConversation'))
int my_conversation = my_conversation_click.substring(my_conversation_click.indexOf('(')+1 , my_conversation_click.indexOf(')')).trim().toInteger()
 println(my_conversation)

 for(int j=1;j<=my_conversation;j++)
	 {
	   //  println(j)
  ElementClick = driver.findElement(By.xpath('(//a[@id="myConversations-tab"]/../../../div/div[@id="myConversations"]/div/div/div[@class="bm-card-details"])[' + j + ']'))
 ElementClick.click()
 robot.keyPress(KeyEvent.VK_DOWN);
 //robot.delay(2000);
 robot.keyRelease(KeyEvent.VK_DOWN);
 robot.keyPress(KeyEvent.VK_DOWN);
 robot.keyRelease(KeyEvent.VK_DOWN);
 robot.keyPress(KeyEvent.VK_DOWN);
 robot.keyRelease(KeyEvent.VK_DOWN);
		 
	 }
 
 List< WebElement> objmyconv= driver.findElements(By.xpath('//a[@id="myConversations-tab"]/../../../div/div[@id="myConversations"]/div/div/div[@class="bm-card-details"]'))
  int myConv_count=	objmyconv.size()
  println(myConv_count)
  for(int k=myConv_count; k>=1;k--)
	  {
  
 // for(int j=1; j<myConv_count;j++)
//   {
	  //println(j)
	  //WebElement obj_conversation = driver.findElement(By.xpath('(//div[@class="small bm-card-date"])[' + unclaimcount_search + ']'))
	   WebElement obj_singlemyconversation= driver.findElement(By.xpath('(//a[@id="myConversations-tab"]/../../../div/div[@id="myConversations"]/div/div/div/div[2])[' + k + ']'))
	  String date_myconv = obj_singlemyconversation.getText()
	  println(date_myconv)
 
  
  String displaynme_unclaimed= WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/displayname'))
  
  println(displaynme_unclaimed)
 
  ElementClick = driver.findElement(By.xpath('(//a[@id="myConversations-tab"]/../../../div/div[@id="myConversations"]/div/div/div[@class="bm-card-details"])[' + k + ']'))
  ElementClick.click()
  robot.keyPress(KeyEvent.VK_UP);
  //robot.delay(2000);
  robot.keyPress(KeyEvent.VK_UP);
  robot.keyPress(KeyEvent.VK_UP);
  robot.keyPress(KeyEvent.VK_UP);
  robot.keyPress(KeyEvent.VK_UP);
  robot.keyPress(KeyEvent.VK_UP);
	  
	 if(date_myconv<today_30dys)
	 {
		// String input = WebUI.setText(findTestObject('Object Repository/Page_Longos Company of Canada/txt_inputmessage'), 'Hello')
		 //WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/button_Send'))
		 List< WebElement> obj_conversation= driver.findElements(By.xpath('//div[@class="messages-subcontainer col-sm-12"]'))
		 int ConversationCount=	obj_conversation.size()
		 println(ConversationCount)
		
		 WebElement last_conversation= driver.findElement(By.xpath('(//div[@class="messages-subcontainer col-sm-12"]/div[2])[' + ConversationCount + ']'))
		 String lastConversation = last_conversation.getText()
		 println(lastConversation)
		 if(lastConversation.contains("Delivered and Read"))

	   {
		   println("this conversation is responsded")
	   }
	   else
	   {
		  // WebUI.verifyElementNotVisible(findTestObject('Object Repository/Page_Longos Company of Canada/unreplied _Count'))
		   WebUI.takeFullPageScreenshot("D://BusinessMessagesScreenshots//verifying_exclamationmark_notPresentmorethan_30days2.png")
		   		   break;
	   }

	 }
	 else
		 {
		 println("this conversation is not older than 30 days ")
	 }
 
	  
  }
 
  WebUI.closeBrowser()

