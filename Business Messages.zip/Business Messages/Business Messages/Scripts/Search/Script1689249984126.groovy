import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import org.testng.Assert as Assert
import org.testng.asserts.SoftAssert as SoftAssert
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.By as By
import org.openqa.selenium.WebElement as WebElement
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import org.openqa.selenium.interactions.Actions as Actions
import org.openqa.selenium.JavascriptExecutor as JavascriptExecutor
import java.awt.AWTException as AWTException
import java.awt.Robot as Robot
import java.awt.event.KeyEvent as KeyEvent

String expected_unclaim_count

String expected_claim_count

int count_unclaim

int count_claim

int expected_claimcount

int expected_unclaimcount

int initial_claimCount

int initial_UnclaimCount

SoftAssert sa = new SoftAssert()

WebUI.callTestCase(findTestCase('Login'), [:], FailureHandling.STOP_ON_FAILURE)

WebUI.switchToWindowTitle('Longos Company of Canada')

driver = DriverFactory.getWebDriver()

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/span_Inbox'))

WebUI.verifyElementVisible(findTestObject('Object Repository/Page_Longos Company of Canada/title'))

WebElement objplaceholder = driver.findElement(By.xpath('//*[@id="unclaimed-search"]'))

String placehoder_value = objplaceholder.getAttribute('placeholder')

println(placehoder_value)

unclaim_count = WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/count_unclaimed'))

initial_UnclaimCount = unclaim_count.substring(unclaim_count.indexOf('(') + 1, unclaim_count.indexOf(')')).trim().toInteger()

println(initial_UnclaimCount)

//expected_unclaimcount=initial_UnclaimCount
//println(expected_unclaimcount)
claim_count = WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/claimed_count'))

initial_claimCount = claim_count.substring(claim_count.indexOf('(') + 1, claim_count.indexOf(')')).trim().toInteger()

println(initial_claimCount)

//expected_claimcount=initial_claimCount
//Assert.assertEquals(count_claim,expected_claimcount)
//Assert.assertEquals(expected_unclaimcount,count_unclaim)
WebUI.setText(findTestObject('Object Repository/Page_Longos Company of Canada/input_Read Manual_unclaimed-search'), 'r')

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/i_Read Manual_unclaimed-search-btn'))

unclaim_count = WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/count_unclaimed'))

count_unclaim = unclaim_count.substring(unclaim_count.indexOf('(') + 1, unclaim_count.indexOf(')')).trim().toInteger()

println(count_unclaim)

//expected_unclaimcount=count_unclaim
claim_count = WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/claimed_count'))

count_claim = claim_count.substring(claim_count.indexOf('(') + 1, claim_count.indexOf(')')).trim().toInteger()

println(count_claim)

//expected_claimcount=count_claim
Assert.assertEquals(count_claim, initial_claimCount)

Assert.assertEquals(initial_UnclaimCount, count_unclaim)

WebUI.setText(findTestObject('Object Repository/Page_Longos Company of Canada/input_Read Manual_unclaimed-search'), 'ra')

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/i_Read Manual_unclaimed-search-btn'))

unclaim_count = WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/count_unclaimed'))

count_unclaim = unclaim_count.substring(unclaim_count.indexOf('(') + 1, unclaim_count.indexOf(')')).trim().toInteger()

println(count_unclaim)

//expected_unclaimcount=count_unclaim
claim_count = WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/claimed_count'))

count_claim = claim_count.substring(claim_count.indexOf('(') + 1, claim_count.indexOf(')')).trim().toInteger()

println(count_claim)

//expected_claimcount=count_claim
Assert.assertEquals(count_claim, initial_claimCount)

Assert.assertEquals(initial_UnclaimCount, count_unclaim)

WebUI.takeFullPageScreenshot('D://BusinessMessagesScreenshots//Search_0.png')

WebUI.setText(findTestObject('Object Repository/Page_Longos Company of Canada/input_Read Manual_unclaimed-search'), 'rah')

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/i_Read Manual_unclaimed-search-btn'))

unclaim_count = WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/count_unclaimed'))

count_unclaim = unclaim_count.substring(unclaim_count.indexOf('(') + 1, unclaim_count.indexOf(')')).trim().toInteger()

println(count_unclaim)

//expected_unclaimcount=count_unclaim
claim_count = WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/claimed_count'))

count_claim = claim_count.substring(claim_count.indexOf('(') + 1, claim_count.indexOf(')')).trim().toInteger()

println(count_claim)

//expected_claimcount=count_claim
Assert.assertNotEquals(count_claim, initial_claimCount)

Assert.assertNotEquals(initial_UnclaimCount, count_unclaim)

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/unclaim_click'))

//Actions act = new Actions(driver)
//act.sendKeys(Keys.ARROW_DOWN).perform()
//act.sendKeys(Keys.ARROW_DOWN).perform()
//act.keyDown(DOWN).build().perform()
//WebUI.delay(5000)
//act.keyUp(DOWN).build().perform()
//act.perform()
Robot robot = new Robot()

robot.keyPress(KeyEvent.VK_DOWN)

//robot.delay(8000); 
//robot.keyRelease(KeyEvent.VK_DOWN);
robot.keyPress(KeyEvent.VK_DOWN)

robot.keyPress(KeyEvent.VK_DOWN)

robot.keyPress(KeyEvent.VK_DOWN)

//robot.delay(4000); 
//robot.keyRelease(KeyEvent.VK_DOWN);
// sa.assertAll()
////div[@class="col-sm-10 bm-card-container"]
//WebElement objunclaim_search = driver.findElement(By.xpath('//div[@class="bm-card-details bold"]/div'))
//WebUI.executeJavaScript("arguments[0].click();", Arrays.asList(objunclaim_search))
List<WebElement> objunclaim_search = driver.findElements(By.xpath('//div[@class="bm-card-details bold"]/div'))

int unclaimcount_search = objunclaim_search.size()

println(unclaimcount_search)

for (int j = 1; j <= unclaimcount_search; j = (j + 2)) {
    println(j)

    //WebElement obj_conversation = driver.findElement(By.xpath('(//div[@class="small bm-card-date"])[' + unclaimcount_search + ']'))
    WebElement obj_singleconversation = driver.findElement(By.xpath(('(//div[@class="bm-card-details bold"]/div)[' + j) + 
            ']'))

    String conversation_text = obj_singleconversation.getText()

    println(conversation_text)

    //WebElement obj_singleconversation = driver.findElement(By.xpath('//div[@class="bm-card-details bold"]/div[1]'))
    Assert.assertTrue(conversation_text.toLowerCase().contains(String.valueOf('rah').toLowerCase()))
}

WebUI.takeFullPageScreenshot('D://BusinessMessagesScreenshots//Search_1.png')

String claim_count = WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/claimed_count'))

String count_claimSearch = claim_count.substring(claim_count.indexOf('(') + 1, claim_count.indexOf(')')).trim().toInteger()

println(count_claimSearch)

String my_conversation_count = WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/myConversation'))

int my_conversation = my_conversation_count.substring(my_conversation_count.indexOf('(') + 1, my_conversation_count.indexOf(
        ')')).trim().toInteger()

println(my_conversation)

String other_conversation_click = WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/claimed_otherConversation'))

int other_conversation = other_conversation_click.substring(other_conversation_click.indexOf('(') + 1, other_conversation_click.indexOf(
        ')')).trim().toInteger()

println(other_conversation)

if (count_claim != 0) {
    List<WebElement> objclaim_searchMyconvs = driver.findElements(By.xpath('//div[@class="bm-card-details"]/div[1]'))

    int claimcount_search = objclaim_searchMyconvs.size()

    println(claimcount_search)

    for (int j = 1; j <= claimcount_search; j = (j + 2)) {
        println(j)

        //WebElement obj_conversation = driver.findElement(By.xpath('(//div[@class="small bm-card-date"])[' + unclaimcount_search + ']'))
        WebElement obj_singleconversation = driver.findElement(By.xpath(('(//div[@class="bm-card-details"]/div)[' + j) + 
                ']'))

        String conversation_text = obj_singleconversation.getText()

        println(conversation_text)

        //WebElement obj_singleconversation = driver.findElement(By.xpath('//div[@class="bm-card-details bold"]/div[1]'))
        Assert.assertTrue(conversation_text.toLowerCase().contains(String.valueOf('rah').toLowerCase()))
    }
    //WebElement obj_conversation = driver.findElement(By.xpath('(//div[@class="small bm-card-date"])[' + unclaimcount_search + ']'))
    //WebElement obj_singleconversation = driver.findElement(By.xpath('//div[@class="bm-card-details bold"]/div[1]'))
} else if (other_conversation != 0) {
    WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/claimed_otherConversation'))

    List<WebElement> objclaim_searchOtherconvs = driver.findElements(By.xpath('//div[@class="bm-card-details"]/div[1]'))

    int claimOtherconvcount_search = objclaim_searchOtherconvs.size()

    println(claimOtherconvcount_search)

    for (int j = 1; j <= claimOtherconvcount_search; j = (j + 2)) {
        println(j)

        WebElement obj_otherconversation = driver.findElement(By.xpath(('(//div[@class="bm-card-details"]/div)[' + j) + 
                ']'))

        String otherconversation_text = obj_otherconversation.getText()

        println(otherconversation_text)

        Assert.assertTrue(otherconversation_text.toLowerCase().contains(String.valueOf('rah').toLowerCase()))
    }
} else {
    println('No data to display')
}

WebUI.takeFullPageScreenshot('D://BusinessMessagesScreenshots//Search_2.png')

/*
//WebElement dropdown = driver.findElement(By.xpath('(//div[@class="small bm-card-date"])[4]'))

/*
// Specify the locator of the element you want to scroll to
String elementLocator = '(//div[@class="small bm-card-date"])[' + count_unclaim + ']'

// Use WebUI.scrollToElement to scroll to the element
WebUI.scrollToElement(findTestObject(elementLocator), 5)
//JavascriptExecutor js = (JavascriptExecutor) driver

//js.executeScript("window.scrollBy(0,1000)", dropdown)
WebUI.delay(10)
WebElement dropdown1 = driver.findElement(By.xpath('(//div[@class="small bm-card-date"])[' + count_unclaim + ']'))
//WebElement dropdown = driver.findElement(By.xpath('(//div[@class="small bm-card-date"])[' + count_unclaim + ']'))
// Create a JavascriptExecutor instance
JavascriptExecutor js1 = (JavascriptExecutor) driver
js1.executeScript("arguments[0].scrollDown += 100;", dropdown1)

WebUI.delay(10)
// Scroll down within the div element
//jsExecutor.executeScript("arguments[0].scrollTop += 100;", divElement)



Actions actions = new Actions(driver)
actions.s

actions.moveToElement(dropdown).click().perform()

actions.sendKeys(Keys.ARROW_UP).perform()

List< WebElement> objunclaim_search= driver.findElements(By.xpath('//div[@class="col-sm-10 bm-card-container"]'))
int unclaimcount_search=	objunclaim_search.size()
println(unclaimcount_search)
*/
//WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/i_Read Manual_unclaimed-search-btn'))
//WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/a_Other Conversations (1)'))
WebUI.setText(findTestObject('Object Repository/Page_Longos Company of Canada/input_Read Manual_unclaimed-search'), 'm')

unclaim_count = WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/count_unclaimed'))

unclaim_count = WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/count_unclaimed'))

count_unclaim = unclaim_count.substring(unclaim_count.indexOf('(') + 1, unclaim_count.indexOf(')')).trim().toInteger()

println(count_unclaim)

//expected_unclaimcount=count_unclaim
claim_count = WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/claimed_count'))

count_claim = claim_count.substring(claim_count.indexOf('(') + 1, claim_count.indexOf(')')).trim().toInteger()

println(count_claim)

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/i_Read Manual_unclaimed-search-btn'))

WebUI.setText(findTestObject('Object Repository/Page_Longos Company of Canada/input_Read Manual_unclaimed-search'), 'me')

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/i_Read Manual_unclaimed-search-btn'))

//unclaim_count= WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/count_unclaimed'))
unclaim_count = WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/count_unclaimed'))

count_unclaim = unclaim_count.substring(unclaim_count.indexOf('(') + 1, unclaim_count.indexOf(')')).trim().toInteger()

println(count_unclaim)

//expected_unclaimcount=count_unclaim
claim_count = WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/claimed_count'))

count_claim = claim_count.substring(claim_count.indexOf('(') + 1, claim_count.indexOf(')')).trim().toInteger()

println(count_claim)

WebUI.setText(findTestObject('Object Repository/Page_Longos Company of Canada/input_Read Manual_unclaimed-search'), 'men')

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/i_Read Manual_unclaimed-search-btn'))

unclaim_count = WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/count_unclaimed'))

unclaim_count = WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/count_unclaimed'))

count_unclaim = unclaim_count.substring(unclaim_count.indexOf('(') + 1, unclaim_count.indexOf(')')).trim().toInteger()

println(count_unclaim)

//expected_unclaimcount=count_unclaim
claim_count = WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/claimed_count'))

count_claim = claim_count.substring(claim_count.indexOf('(') + 1, claim_count.indexOf(')')).trim().toInteger()

println(count_claim)

WebUI.delay(10)

List<WebElement> objunclaim1_search = driver.findElements(By.xpath('//div[@class="bm-card-details bold"]/div'))

int unclaimcount_search1 = objunclaim1_search.size()

println(unclaimcount_search1)

for (int j = 1; j <= unclaimcount_search1; j = (j + 2)) {
    println(j)

    //WebElement obj_conversation = driver.findElement(By.xpath('(//div[@class="small bm-card-date"])[' + unclaimcount_search + ']'))
    WebElement obj_singleconversation = driver.findElement(By.xpath(('(//div[@class="bm-card-details bold"]/div)[' + j) + 
            ']'))

    String conversation_text = obj_singleconversation.getText()

    println(conversation_text)

    //WebElement obj_singleconversation = driver.findElement(By.xpath('//div[@class="bm-card-details bold"]/div[1]'))
    Assert.assertTrue(conversation_text.toLowerCase().contains(String.valueOf('men').toLowerCase()))
}

WebUI.takeFullPageScreenshot('D://BusinessMessagesScreenshots//Search_3.png')

WebUI.setText(findTestObject('Object Repository/Page_Longos Company of Canada/input_Read Manual_unclaimed-search'), 'hrl')

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/i_Read Manual_unclaimed-search-btn'))

unclaim_count = WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/count_unclaimed'))

count_unclaim = unclaim_count.substring(unclaim_count.indexOf('(') + 1, unclaim_count.indexOf(')')).trim().toInteger()

println(count_unclaim)

//expected_unclaimcount=count_unclaim
claim_count = WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/claimed_count'))

count_claim = claim_count.substring(claim_count.indexOf('(') + 1, claim_count.indexOf(')')).trim().toInteger()

println(count_claim)

if ((count_unclaim == 0) && (count_claim == 0)) {
    Assert.assertTrue(true)
} else {
    Assert.assertFalse(true)
}

WebUI.takeFullPageScreenshot('D://BusinessMessagesScreenshots//Search_4.png')

WebUI.closeBrowser()

