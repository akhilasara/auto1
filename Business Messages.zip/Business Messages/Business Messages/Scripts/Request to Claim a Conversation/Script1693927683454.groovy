import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import org.testng.Assert as Assert
import org.testng.asserts.SoftAssert

SoftAssert sa = new SoftAssert()

WebUI.callTestCase(findTestCase('Login'),  [:], FailureHandling.STOP_ON_FAILURE)

WebUI.switchToWindowTitle('Longos Company of Canada')

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/span_Inbox'))

WebUI.verifyElementVisible(findTestObject('Object Repository/Page_Longos Company of Canada/title'))

WebUI.verifyElementVisible(findTestObject('Object Repository/Page_Longos Company of Canada/Google_logo'))

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/claimed_click'))

String my_conversation_click= WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/myConversation'))

int my_conversation = my_conversation_click.substring(my_conversation_click.indexOf('(')+1 , my_conversation_click.indexOf(')')).trim().toInteger()

println(my_conversation)

int expected_muConversationCount=my_conversation+1

println(expected_muConversationCount)

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/claimed_otherConversation'))

String other_conversation_click= WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/claimed_otherConversation'))

int other_conversation = other_conversation_click.substring(other_conversation_click.indexOf('(')+1 , other_conversation_click.indexOf(')')).trim().toInteger()

println(other_conversation)

int expected_other_conversationCount=other_conversation-1

println(other_conversation)
	
WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/otherCOnversation_first'))

WebUI.takeFullPageScreenshot("D://BusinessMessagesScreenshots//RequestToClaimConversation1.png")

WebUI.verifyElementPresent(findTestObject('Object Repository/Page_Longos Company of Canada/a_Request to claim'), 0)

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/a_Request to claim'))

String actual_my_conversation_click= WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/myConversation'))

int actual_my_conversationCount = actual_my_conversation_click.substring(actual_my_conversation_click.indexOf('(')+1 , actual_my_conversation_click.indexOf(')')).trim().toInteger()

println(actual_my_conversationCount)

String actual_other_conversation_click= WebUI.getText(findTestObject('Object Repository/Page_Longos Company of Canada/claimed_otherConversation'))

int actual_other_conversation = actual_other_conversation_click.substring(actual_other_conversation_click.indexOf('(')+1 , actual_other_conversation_click.indexOf(')')).trim().toInteger()

println(actual_other_conversation)

sa.assertEquals(actual_my_conversationCount,expected_muConversationCount)
sa.assertEquals(actual_other_conversation,expected_other_conversationCount)
WebUI.takeFullPageScreenshot("D://BusinessMessagesScreenshots//RequestToClaimConversation2.png")
sa.assertAll()
WebUI.closeBrowser()