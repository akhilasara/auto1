import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.By as By
import org.openqa.selenium.WebElement as WebElement
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import java.text.SimpleDateFormat as SimpleDateFormat
import org.testng.Assert as Assert
import org.testng.asserts.SoftAssert as SoftAssert
import java.sql.Timestamp as Timestamp
import java.time.Instant as Instant

String agent_name

String msg_date, msg
String dateFormat = 'MM-dd'//HH:mm'

SimpleDateFormat sdf = new SimpleDateFormat(dateFormat)

WebUI.callTestCase(findTestCase('Login'), [:], FailureHandling.STOP_ON_FAILURE)

WebUI.switchToWindowTitle('Longos Company of Canada')

WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/span_Inbox'))

driver = DriverFactory.getWebDriver()

String user = findTestData('Data').getValue('Username', 2)

println(user)

SoftAssert sa = new SoftAssert()



WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/claimed_click'))

WebUI.verifyElementPresent(findTestObject('Object Repository/Page_Longos Company of Canada/txt_inputmessage'), 0)

WebUI.takeFullPageScreenshot("D://BusinessMessagesScreenshots//replyToConversation1.png")

String input = WebUI.setText(findTestObject('Object Repository/Page_Longos Company of Canada/txt_inputmessage'), 'Hello')
Date currentDate = new Date()

// Format the current date using the SimpleDateFormat object
String formattedDate = sdf.format(currentDate)

// Print the formatted date
println('Current Date: ' + formattedDate)
WebUI.click(findTestObject('Object Repository/Page_Longos Company of Canada/button_Send'))

//WebElement agentName = driver.findElement(By.xpath('//div[@class="messages-subcontainer col-sm-12"]/div/div/div[@class="agentName"]'))
List<WebElement> agentName = driver.findElements(By.xpath('//div[@class="messages-subcontainer col-sm-12"]/div/div/div[@class="agentName"]'))

int size_agent = agentName.size()

println(size_agent)

for (int j = 1; j <= size_agent; j++) {
    //(//div[@class="messages-subcontainer col-sm-12"]/div/div/div[@class="agentName"])[ 2]
    WebElement ele_name = driver.findElement(By.xpath(('(//div[@class="messages-subcontainer col-sm-12"]/div/div/div[@class="agentName"])[' + 
            j) + ']'))

    agent_name = ele_name.getText()
}

List<WebElement> objmsgDate = driver.findElements(By.xpath('//div[@class="messages-subcontainer col-sm-12"]/div/div/div[@class="msgDate"]'))

int size_date = objmsgDate.size()

println(size_date)

for (int j = 1; j <= size_date; j++) {
    //(//div[@class="messages-subcontainer col-sm-12"]/div/div/div[@class="agentName"])[ 2]
    WebElement ele_date = driver.findElement(By.xpath(('(//div[@class="messages-subcontainer col-sm-12"]/div/div/div[@class="msgDate"])[' + 
            j) + ']'))

    msg_date = ele_date.getText()
}

List<WebElement> objmsg = driver.findElements(By.xpath('//div[@class="messages-subcontainer col-sm-12"]/div/div[@class="body"]'))

int size_msg = objmsg.size()

println(size_msg)

for (int j = 1; j <= size_msg; j++) {
	//(//div[@class="messages-subcontainer col-sm-12"]/div/div/div[@class="agentName"])[ 2]
	WebElement ele_msg = driver.findElement(By.xpath('(//div[@class="messages-subcontainer col-sm-12"]/div/div[@class="body"])[' +
			j + ']'))

	msg = ele_msg.getText()
}

println(agent_name)
String msgcreated_Date = msg_date.substring(0, 5)

println(msg_date)
println(msg)
Assert.assertEquals(user,agent_name)
Assert.assertEquals(formattedDate,msgcreated_Date)
Assert.assertEquals(msg,"Hello")
//WebUI.takeFullPageScreenshot()


//WebUI.takeFullPageScreenshot()


//WebUI.delay(15)
 WebUI.takeFullPageScreenshot("D://BusinessMessagesScreenshots//replyToConversation2.png")
WebUI.closeBrowser()

