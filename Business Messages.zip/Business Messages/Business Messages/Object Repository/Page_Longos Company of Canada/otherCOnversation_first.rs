<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>otherCOnversation_first</name>
   <tag></tag>
   <elementGuidId>ee6c43ac-d24e-417b-9a31-727bacc5c708</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//div[@id=&quot;myConversations&quot;]/..//div/div/div[@class=&quot;bm-card-details bold&quot;]/div)[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
