<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_RM                                     _e2494b</name>
   <tag></tag>
   <elementGuidId>6213bb24-e0af-4554-908f-9e0851bee5b9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='myConversations']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#myConversations</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>6d26615e-4840-4a0f-9359-52223a6a7270</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>tabpanel</value>
      <webElementGuid>d966bfb8-9e9f-4c9e-a81c-07692918f809</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>claimed-unclaimed-grid tab-pane fade in active</value>
      <webElementGuid>8f7d6fad-f611-4c7e-9d1d-afb677d3cf90</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>myConversations</value>
      <webElementGuid>0ec918d4-5452-4761-a54b-6e383097beb0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 5.44 pm
                        Claimed by you
                    
                                
            
                
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 4.54 pm
                        Claimed by you
                    
                                
            
                
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 4.49 pm
                        Claimed by you
                    
                                
            </value>
      <webElementGuid>511751db-72b0-40d0-bc69-300df9b51036</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;myConversations&quot;)</value>
      <webElementGuid>db53ab5b-b0d7-489d-bb29-15fa9d67a27a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='myConversations']</value>
      <webElementGuid>15d86c06-fe7f-44a5-9968-8f37a68444a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-content']/div[2]/div/div/div[2]/div/div/div</value>
      <webElementGuid>9964bae3-9693-4e28-b2f7-23d2faa81c99</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(0)'])[1]/following::div[2]</value>
      <webElementGuid>a5efc6b5-f8e0-4a4d-9814-c7806d2342a6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div[2]/div/div/div</value>
      <webElementGuid>f5be54f1-5b2a-4232-a4bb-c3729fe97cbb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[@id = 'myConversations' and (text() = '
                
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 5.44 pm
                        Claimed by you
                    
                                
            
                
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 4.54 pm
                        Claimed by you
                    
                                
            
                
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 4.49 pm
                        Claimed by you
                    
                                
            ' or . = '
                
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 5.44 pm
                        Claimed by you
                    
                                
            
                
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 4.54 pm
                        Claimed by you
                    
                                
            
                
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 4.49 pm
                        Claimed by you
                    
                                
            ')]</value>
      <webElementGuid>c4ac1221-2e54-412e-8d46-921aede58eda</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
