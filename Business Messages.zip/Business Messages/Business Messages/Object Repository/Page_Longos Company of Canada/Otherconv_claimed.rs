<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Otherconv_claimed</name>
   <tag></tag>
   <elementGuidId>fe16ac39-5672-4862-97c9-27750cbb84da</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@id=&quot;myConversations&quot;]/..//div/div/div[@class=&quot;bm-card-details bold&quot;]/div)[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
