<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Message  5.44 pm</name>
   <tag></tag>
   <elementGuidId>1e66a05a-06d3-4ec6-9eed-d58eef5f2cb6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='55']/div[2]/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#55 > div.col-sm-10.bm-card-container > div.bm-card-message</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>bc2324a3-a648-4d64-8654-720c7ef149ba</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>bm-card-message</value>
      <webElementGuid>4a90ce6b-fe13-4607-8665-7e1279609791</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Message @ 5.44 pm</value>
      <webElementGuid>4a118111-8065-4d8c-81ea-59b3068f7441</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;55&quot;)/div[@class=&quot;col-sm-10 bm-card-container&quot;]/div[@class=&quot;bm-card-message&quot;]</value>
      <webElementGuid>8d28cce2-81c1-4fcc-971b-d63968d98f36</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='55']/div[2]/div[2]</value>
      <webElementGuid>8a33fa10-d7c2-4c8a-b6a9-643c9db0a6bb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rahul Menon'])[2]/following::div[2]</value>
      <webElementGuid>23976793-7b96-44a8-8461-3c1d90bf4531</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RM'])[2]/following::div[5]</value>
      <webElementGuid>61f7dde4-d739-4d9a-9b64-b936fe81d611</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Claimed by you'])[1]/preceding::div[1]</value>
      <webElementGuid>caa6652f-fd4c-457f-a501-c708f954d938</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RM'])[3]/preceding::div[2]</value>
      <webElementGuid>1156a0d2-ed13-4d48-a216-6f038bdfb5c7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Message @ 5.44 pm']/parent::*</value>
      <webElementGuid>4026cdfe-c6b3-4568-9ffa-4d8cdc1f0600</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div[2]/div/div/div/div/div[2]/div[2]</value>
      <webElementGuid>b1765083-98f9-4a71-b087-a6af729349fe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Message @ 5.44 pm' or . = 'Message @ 5.44 pm')]</value>
      <webElementGuid>740120c1-6fb9-4226-bfc1-0a88f369b9b0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
