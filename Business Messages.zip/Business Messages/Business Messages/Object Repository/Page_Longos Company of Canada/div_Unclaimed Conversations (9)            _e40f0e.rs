<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Unclaimed Conversations (9)            _e40f0e</name>
   <tag></tag>
   <elementGuidId>4c7df061-12de-4cf5-ba6e-f24da9adff01</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;unclaim-btn&quot;]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.row.border-top</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>6e13fa09-7021-43b2-82ec-19ddae184fb6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>row border-top</value>
      <webElementGuid>226a17ee-d322-4747-96e8-728477e8f9dc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
            
                
                    
                        
                            
                            
                        
                    

                    Unclaimed Conversations (9)
                    
                
                    JC
                    
                        
                            Juliana de Carvalho
                            06-28 
                        
                        **** * **** ******* 
                        
                    
                                
            
                
                    JE
                    
                        
                            Jeff
                            06-21 
                        
                        **** ** **** **** ****** 
                        
                    
                                
            
                
                    JC
                    
                        
                            Juliana de Carvalho
                            06-21 
                        
                        **** **** ****** ******** 
                        
                    
                                
            
                
                    RM
                    
                        
                            Rahul Menon
                            06-07 
                        
                        *** ***** *******
                        
                    
                                
            
                
            
            
                Claimed Conversations (26)
                
                        
                        
                        
                            My Conversations (22)
                            Other Conversations (4)
                        
                        
                        
                            
                
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 4.54 pm
                        Claimed by you
                    
                                
            
                
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 4.49 pm
                        Claimed by you
                    
                                
            
                
                    DT
                    
                        
                            dac test
                            05-15 
                        
                        Hello
                        Claimed by you
                    
                                
            
                
                    R
                    
                        
                            R
                            04-14 
                        
                        Sounds good
                        Claimed by you
                    
                                
            
                            
                            
                        

                
            
        
        
            
        
            RM 
            Rahul Menon
        
        
        
            
            
                
                    
                        
                        06-21 3:45 PM
                    
                    
                    This is a new message from Madrid location
                    
                
                
            
            
            
                
                    
                        larry_nn_email
                        06-21 3:55 PM
                    
                    
                    Message from Madrid location is well received on dashboard
                    
                
                Delivered and Read
            
            
            
                
                    
                        
                        06-26 9:03 PM
                    
                    
                    Hello! New message from Madrid @ 9.02 pm
                    
                
                
            
            
            
                
                    
                        aarcha_lekha
                        06-26 9:14 PM
                    
                    
                    Message @9.02 pm is received
                    
                
                Delivered and Read
            
            
            
                
                    
                        
                        06-28 5:18 PM
                    
                    
                    Message from Madrid @ 5.15 pm on 06-28
                    
                
                
            
            
            
                
                    
                        aarcha_lekha
                        06-28 5:22 PM
                    
                    
                    Message is received 
                    
                
                Delivered and Read
            
            
            
                
                    
                        
                        07-05 4:56 PM
                    
                    
                    Message @ 4.54 pm
                    
                
                
            
            
            
                
                    
                        aarcha_lekha
                        07-05 5:22 PM
                    
                    
                    Message is received on dashboard
                    
                
                Delivered and Read
            
            

                
                    
                        To respond, claim this conversation.
                        Claim conversation
                    
                
                
                    
                        
                        This conversation has been claimed by N / A
                        Request to claim
                    
                
                
                    
                        
                            
                            
                                Send
                            
                        
                    
                
                
                    
                        Unclaim conversation to allow another dashboard user to respond.
                    
                

        
        
            
            Customer Information
            
                
                    
                        Name
                        Rahul Menon
                    

                     
                        Device Locale
                        en-IN                    
                    
                    
                    
                        Business Location
                            
                                999901 Bathurst St, Toronto, 
                                ON, CA
                                +14165557042 
                                9000327042 
                                            
                    
                
            
        
    </value>
      <webElementGuid>c7d21b20-1818-453a-b13c-64ef21c48a89</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-content&quot;)/div[@class=&quot;business-messages-container container-fluid&quot;]/div[@class=&quot;row border-top&quot;]</value>
      <webElementGuid>d10ab452-d123-4f93-97cc-853e14f9e084</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-content']/div[2]/div</value>
      <webElementGuid>5d7edcbc-d15a-425c-9dad-c80a16b0f7c0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Read Manual'])[1]/following::div[2]</value>
      <webElementGuid>e913cefe-6dce-41c0-b969-83882e0803c1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Business Messages Conversation Channel'])[1]/following::div[2]</value>
      <webElementGuid>26d78081-b8ae-4381-9b39-e3ddaa97aecd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div[2]/div</value>
      <webElementGuid>1449d96e-634a-42e7-9403-c2def8271162</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
        
            
                
                    
                        
                            
                            
                        
                    

                    Unclaimed Conversations (9)
                    
                
                    JC
                    
                        
                            Juliana de Carvalho
                            06-28 
                        
                        **** * **** ******* 
                        
                    
                                
            
                
                    JE
                    
                        
                            Jeff
                            06-21 
                        
                        **** ** **** **** ****** 
                        
                    
                                
            
                
                    JC
                    
                        
                            Juliana de Carvalho
                            06-21 
                        
                        **** **** ****** ******** 
                        
                    
                                
            
                
                    RM
                    
                        
                            Rahul Menon
                            06-07 
                        
                        *** ***** *******
                        
                    
                                
            
                
            
            
                Claimed Conversations (26)
                
                        
                        
                        
                            My Conversations (22)
                            Other Conversations (4)
                        
                        
                        
                            
                
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 4.54 pm
                        Claimed by you
                    
                                
            
                
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 4.49 pm
                        Claimed by you
                    
                                
            
                
                    DT
                    
                        
                            dac test
                            05-15 
                        
                        Hello
                        Claimed by you
                    
                                
            
                
                    R
                    
                        
                            R
                            04-14 
                        
                        Sounds good
                        Claimed by you
                    
                                
            
                            
                            
                        

                
            
        
        
            
        
            RM 
            Rahul Menon
        
        
        
            
            
                
                    
                        
                        06-21 3:45 PM
                    
                    
                    This is a new message from Madrid location
                    
                
                
            
            
            
                
                    
                        larry_nn_email
                        06-21 3:55 PM
                    
                    
                    Message from Madrid location is well received on dashboard
                    
                
                Delivered and Read
            
            
            
                
                    
                        
                        06-26 9:03 PM
                    
                    
                    Hello! New message from Madrid @ 9.02 pm
                    
                
                
            
            
            
                
                    
                        aarcha_lekha
                        06-26 9:14 PM
                    
                    
                    Message @9.02 pm is received
                    
                
                Delivered and Read
            
            
            
                
                    
                        
                        06-28 5:18 PM
                    
                    
                    Message from Madrid @ 5.15 pm on 06-28
                    
                
                
            
            
            
                
                    
                        aarcha_lekha
                        06-28 5:22 PM
                    
                    
                    Message is received 
                    
                
                Delivered and Read
            
            
            
                
                    
                        
                        07-05 4:56 PM
                    
                    
                    Message @ 4.54 pm
                    
                
                
            
            
            
                
                    
                        aarcha_lekha
                        07-05 5:22 PM
                    
                    
                    Message is received on dashboard
                    
                
                Delivered and Read
            
            

                
                    
                        To respond, claim this conversation.
                        Claim conversation
                    
                
                
                    
                        
                        This conversation has been claimed by N / A
                        Request to claim
                    
                
                
                    
                        
                            
                            
                                Send
                            
                        
                    
                
                
                    
                        Unclaim conversation to allow another dashboard user to respond.
                    
                

        
        
            
            Customer Information
            
                
                    
                        Name
                        Rahul Menon
                    

                     
                        Device Locale
                        en-IN                    
                    
                    
                    
                        Business Location
                            
                                999901 Bathurst St, Toronto, 
                                ON, CA
                                +14165557042 
                                9000327042 
                                            
                    
                
            
        
    ' or . = '
        
            
                
                    
                        
                            
                            
                        
                    

                    Unclaimed Conversations (9)
                    
                
                    JC
                    
                        
                            Juliana de Carvalho
                            06-28 
                        
                        **** * **** ******* 
                        
                    
                                
            
                
                    JE
                    
                        
                            Jeff
                            06-21 
                        
                        **** ** **** **** ****** 
                        
                    
                                
            
                
                    JC
                    
                        
                            Juliana de Carvalho
                            06-21 
                        
                        **** **** ****** ******** 
                        
                    
                                
            
                
                    RM
                    
                        
                            Rahul Menon
                            06-07 
                        
                        *** ***** *******
                        
                    
                                
            
                
            
            
                Claimed Conversations (26)
                
                        
                        
                        
                            My Conversations (22)
                            Other Conversations (4)
                        
                        
                        
                            
                
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 4.54 pm
                        Claimed by you
                    
                                
            
                
                    RM
                    
                        
                            Rahul Menon
                            07-05 
                        
                        Message @ 4.49 pm
                        Claimed by you
                    
                                
            
                
                    DT
                    
                        
                            dac test
                            05-15 
                        
                        Hello
                        Claimed by you
                    
                                
            
                
                    R
                    
                        
                            R
                            04-14 
                        
                        Sounds good
                        Claimed by you
                    
                                
            
                            
                            
                        

                
            
        
        
            
        
            RM 
            Rahul Menon
        
        
        
            
            
                
                    
                        
                        06-21 3:45 PM
                    
                    
                    This is a new message from Madrid location
                    
                
                
            
            
            
                
                    
                        larry_nn_email
                        06-21 3:55 PM
                    
                    
                    Message from Madrid location is well received on dashboard
                    
                
                Delivered and Read
            
            
            
                
                    
                        
                        06-26 9:03 PM
                    
                    
                    Hello! New message from Madrid @ 9.02 pm
                    
                
                
            
            
            
                
                    
                        aarcha_lekha
                        06-26 9:14 PM
                    
                    
                    Message @9.02 pm is received
                    
                
                Delivered and Read
            
            
            
                
                    
                        
                        06-28 5:18 PM
                    
                    
                    Message from Madrid @ 5.15 pm on 06-28
                    
                
                
            
            
            
                
                    
                        aarcha_lekha
                        06-28 5:22 PM
                    
                    
                    Message is received 
                    
                
                Delivered and Read
            
            
            
                
                    
                        
                        07-05 4:56 PM
                    
                    
                    Message @ 4.54 pm
                    
                
                
            
            
            
                
                    
                        aarcha_lekha
                        07-05 5:22 PM
                    
                    
                    Message is received on dashboard
                    
                
                Delivered and Read
            
            

                
                    
                        To respond, claim this conversation.
                        Claim conversation
                    
                
                
                    
                        
                        This conversation has been claimed by N / A
                        Request to claim
                    
                
                
                    
                        
                            
                            
                                Send
                            
                        
                    
                
                
                    
                        Unclaim conversation to allow another dashboard user to respond.
                    
                

        
        
            
            Customer Information
            
                
                    
                        Name
                        Rahul Menon
                    

                     
                        Device Locale
                        en-IN                    
                    
                    
                    
                        Business Location
                            
                                999901 Bathurst St, Toronto, 
                                ON, CA
                                +14165557042 
                                9000327042 
                                            
                    
                
            
        
    ')]</value>
      <webElementGuid>bfc15fb4-f93e-460a-94ae-f5fe4127324e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
