<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Message  4.49 pm</name>
   <tag></tag>
   <elementGuidId>5fb50e2f-57b1-4038-b2b3-056177b21e36</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='56']/div[2]/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#56 > div.col-sm-10.bm-card-container > div.bm-card-message</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>ac561379-6a5a-46fe-aa02-6d2f6ebbe9aa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>bm-card-message</value>
      <webElementGuid>a7ce8ae8-5cc4-435e-aea3-466aaf6b2636</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Message @ 4.49 pm</value>
      <webElementGuid>c3e7f1d1-5396-4a1e-8228-0e9898dcd769</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;56&quot;)/div[@class=&quot;col-sm-10 bm-card-container&quot;]/div[@class=&quot;bm-card-message&quot;]</value>
      <webElementGuid>7ad181d5-099a-4781-a33c-ca8880bfb35f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='56']/div[2]/div[2]</value>
      <webElementGuid>d90fed2d-c01a-47d4-ac55-f60132ff0b15</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rahul Menon'])[2]/following::div[2]</value>
      <webElementGuid>5c07d647-9c92-48a0-aa6e-302962719cb3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RM'])[2]/following::div[5]</value>
      <webElementGuid>040e4d5f-4a85-4b85-ae82-71f1cf98aa0a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Claimed by you'])[1]/preceding::div[1]</value>
      <webElementGuid>f0b29a00-df86-475d-81af-b2fd3a688a6f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RM'])[3]/preceding::div[2]</value>
      <webElementGuid>6b27023c-83ec-4b80-978d-292e594f267d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Message @ 4.49 pm']/parent::*</value>
      <webElementGuid>d39ac6af-550e-4c26-939e-7dbe7d88fc71</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div[2]/div/div/div/div/div[2]/div[2]</value>
      <webElementGuid>15db445c-02b5-4a0a-be89-a867961f6d24</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Message @ 4.49 pm' or . = 'Message @ 4.49 pm')]</value>
      <webElementGuid>88a92214-97ba-4a1e-8152-82a89fd307fa</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
